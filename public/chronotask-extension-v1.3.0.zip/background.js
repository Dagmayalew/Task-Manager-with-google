// Chronotask Service Worker v1.3.0
chrome.runtime.onInstalled.addListener(() => {
  console.log('Chronotask extension v1.3.0 installed successfully.');
  updateBadge();
});

// Configure side panel behavior
if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => {});
}

// Update icon badge with count of today's pending tasks
async function updateBadge() {
  try {
    const data = await chrome.storage.local.get(['chronotask_tasks_v1']);
    const raw = data.chronotask_tasks_v1 ? JSON.parse(data.chronotask_tasks_v1) : [];
    const today = new Date().toISOString().split('T')[0];
    const pendingToday = raw.filter(t => !t.completed && t.due === today).length;
    
    if (pendingToday > 0) {
      chrome.action.setBadgeText({ text: String(pendingToday) });
      chrome.action.setBadgeBackgroundColor({ color: '#e11d48' });
    } else {
      chrome.action.setBadgeText({ text: '' });
    }
  } catch (e) {
    // ignore
  }
}

// Listen for storage changes to keep badge updated
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.chronotask_tasks_v1) {
    updateBadge();
  }
});

// Listen for sync completion messages
chrome.runtime.onMessage.addListener((message) => {
  if (message && message.type === 'SYNC_COMPLETED') {
    updateBadge();
  }
});
