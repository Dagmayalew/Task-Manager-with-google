# Chronotask Chrome Extension Installation Guide

Thank you for downloading Chronotask! This extension gives you instant quick-capture, side-panel productivity, Google Tasks synchronization, and Google Calendar time-blocking.

## 🚀 How to Load Unpacked in Google Chrome:

1. **Extract or Save the Files**:
   Ensure all files from this extension package are saved into a dedicated folder on your computer (e.g., `Documents/chronotask-extension`).
   
   Structure:
   - `manifest.json`
   - `background.js`
   - `content.js` (Real-Time Bidirectional Sync Bridge with https://task-manager-with-google.vercel.app)
   - `popup.html`
   - `popup.css`
   - `popup.js`
   - `sidepanel.html`
   - `icons/`

2. **Open Extensions Page in Chrome**:
   - In Google Chrome address bar, navigate to: `chrome://extensions`
   - Or click the three dots menu (⋮) -> **Extensions** -> **Manage Extensions**.

3. **Enable Developer Mode**:
   - In the top-right corner of the Extensions page, switch the **"Developer mode"** toggle to **ON**.

4. **Load the Extension**:
   - Click the **"Load unpacked"** button in the top-left toolbar.
   - Select your `chronotask-extension` folder.

5. **Pin to Toolbar**:
   - Click the puzzle icon (🧩) on your Chrome toolbar.
   - Find **Chronotask** and click the pin icon.

6. **Keyboard Shortcut**:
   - Press **`Command+Shift+T`** (Mac) or **`Ctrl+Shift+T`** (Windows/Linux) anytime to instantly toggle your tasks!
