// Chronotask Extension Sync Bridge v0.3.0
// Synchronizes tasks and folders bidirectionally between Chronotask Web App and chrome.storage.local

(function() {
  // Prevent execution inside embedded or third-party iframes
  if (window !== window.top) return;

  // Only run on the official verified Chronotask web application
  const ALLOWED_ORIGINS = [
    'https://task-manager-with-google.vercel.app'
  ];
  if (ALLOWED_ORIGINS.indexOf(window.location.origin) < 0) return;

  console.log('[Chronotask Bridge] Initialized on ' + window.location.href);
  const appOrigin = window.location.origin;

  // Tokens are intentionally kept in the web app only. Remove values written by
  // older exports so upgrading the extension also clears the stale credential.
  chrome.storage.local.remove(['chronotask_access_token']);

  const PRIORITIES = ['urgent', 'high', 'medium', 'low'];

  function text(value, max) {
    return typeof value === 'string' ? value.slice(0, max) : '';
  }

  function sanitizeTask(task, index) {
    if (!task || typeof task !== 'object') return null;
    const clean = Object.assign({}, task);
    clean.id = text(task.id, 128) || 'task_' + index;
    clean.title = text(task.title, 500);
    clean.notes = typeof task.notes === 'string' ? task.notes.slice(0, 2000) : undefined;
    clean.completed = Boolean(task.completed);
    clean.priority = PRIORITIES.indexOf(task.priority) >= 0 ? task.priority : 'medium';
    clean.due = typeof task.due === 'string' && /^[0-9]{4}-[0-9]{2}-[0-9]{2}([T ].*)?$/.test(task.due)
      ? task.due.slice(0, 40)
      : undefined;
    if (typeof task.folderId === 'string') clean.folderId = task.folderId.slice(0, 128);
    if (typeof task.listId === 'string') clean.listId = task.listId.slice(0, 128);
    return clean;
  }

  function sanitizeList(list, index) {
    if (!list || typeof list !== 'object') return null;
    const clean = Object.assign({}, list);
    clean.id = text(list.id, 128) || 'list_' + index;
    clean.title = text(list.title, 200);
    if (typeof list.color === 'string' && /^#[0-9a-fA-F]{6}$/.test(list.color)) {
      clean.color = list.color;
    } else {
      delete clean.color;
    }
    return clean;
  }

  // Send extension's stored tasks and folders to web app
  function sendExtensionStateToWeb() {
    try {
      chrome.storage.local.get(['chronotask_tasks_v1', 'chronotask_lists_v1', 'chronotask_last_synced'], (res) => {
        if (chrome.runtime.lastError) return;
        const tasks = res.chronotask_tasks_v1 ? JSON.parse(res.chronotask_tasks_v1) : [];
        const lists = res.chronotask_lists_v1 ? JSON.parse(res.chronotask_lists_v1) : [];
        window.postMessage({
          type: 'CHRONOTASK_SYNC_FROM_EXTENSION',
          source: 'chronotask-extension',
          tasks,
          lists,
          lastSynced: res.chronotask_last_synced || null
        }, appOrigin);
      });
    } catch (e) {
      console.warn('[Chronotask Bridge] Read storage error:', e);
    }
  }

  // Request current state from web app
  function requestPageState() {
    window.postMessage({
      type: 'CHRONOTASK_PING_FOR_STATE',
      source: 'chronotask-extension'
    }, appOrigin);
  }

  // Trigger sync on start and at multiple lifecycle stages
  sendExtensionStateToWeb();
  requestPageState();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      sendExtensionStateToWeb();
      requestPageState();
    });
  }
  window.addEventListener('load', () => {
    sendExtensionStateToWeb();
    requestPageState();
  });

  // Automated continuous periodic sync every 3 seconds while web app is open
  setInterval(() => {
    requestPageState();
  }, 3000);

  // Listen for messages from web app (App.tsx)
  window.addEventListener('message', (event) => {
    if (event.source !== window || event.origin !== appOrigin) return;
    if (!event.data || typeof event.data !== 'object') return;
    if (event.data.source === 'chronotask-extension') return; // Ignore own messages

    if (event.data.type === 'CHRONOTASK_SYNC_TO_EXTENSION') {
      if (event.data.source !== 'chronotask-web-app') return;
      const updateData = {};
      if (Array.isArray(event.data.tasks)) {
        const tasks = event.data.tasks.slice(0, 1000).map(sanitizeTask).filter(Boolean);
        updateData['chronotask_tasks_v1'] = JSON.stringify(tasks);
      }
      if (Array.isArray(event.data.lists)) {
        const lists = event.data.lists.slice(0, 200).map(sanitizeList).filter(Boolean);
        updateData['chronotask_lists_v1'] = JSON.stringify(lists);
      }
      if (event.data.user && typeof event.data.user === 'object') {
        updateData['chronotask_user'] = JSON.stringify({
          email: text(event.data.user.email, 200),
          displayName: text(event.data.user.displayName, 200)
        });
      }
      if (typeof event.data.lastSynced === 'string' && !isNaN(Date.parse(event.data.lastSynced))) {
        updateData['chronotask_last_synced'] = event.data.lastSynced.slice(0, 40);
      }

      chrome.storage.local.set(updateData, () => {
        try {
          chrome.runtime.sendMessage({ type: 'SYNC_COMPLETED', count: tasks ? tasks.length : 0 }).catch(() => {});
        } catch (_) {}
      });
    }

    if (event.data.type === 'CHRONOTASK_REQUEST_EXTENSION_SYNC') {
      sendExtensionStateToWeb();
    }
  });

  // Watch for changes made within extension popup/sidepanel while web app is open
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && (changes.chronotask_tasks_v1 || changes.chronotask_lists_v1)) {
      sendExtensionStateToWeb();
    }
  });

  // Listen for direct sync triggers from extension popup
  if (chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request && request.type === 'TRIGGER_PAGE_SYNC') {
        sendExtensionStateToWeb();
        requestPageState();
        sendResponse({ status: 'ok' });
      }
    });
  }
})();
