// Chronotask Extension Popup Logic v1.3.2
let currentFilter = 'today';
let selectedFolderId = 'all';
let prioritySortHighToLow = true;
let editingTaskId = null;

const PRIORITY_WEIGHT = {
  urgent: 4,
  high: 3,
  medium: 2,
  low: 1,
};

const DEFAULT_FOLDERS = [
  { id: 'default_my_tasks', title: 'General', color: '#1e4fd8' },
  { id: 'default_work', title: 'Work & Projects', color: '#059669' },
  { id: 'default_personal', title: 'Personal', color: '#7c3aed' },
  { id: 'default_urgent', title: 'Urgent & Critical', color: '#e11d48' },
];

function isChronotaskTab(tab) {
  if (!tab || !tab.url) return false;
  try {
    const parsed = new URL(tab.url);
    return parsed.origin === 'https://task-manager-with-google.vercel.app';
  } catch (e) {
    return false;
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  await renderFolderDropdowns();
  await renderTasks();
  await updateSyncStatus();

  // On popup open, immediately trigger a sync check with any open Chronotask tab
  if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.query) {
    chrome.tabs.query({}, (tabs) => {
      const matchTab = tabs.find(isChronotaskTab);
      if (matchTab && matchTab.id) {
        chrome.tabs.sendMessage(matchTab.id, { type: 'TRIGGER_PAGE_SYNC' }, () => {});
      }
    });
  }

  // Periodic automatic sync check while popup is open
  setInterval(async () => {
    await renderTasks();
    await updateSyncStatus();
  }, 2500);

  // Listen for real-time changes synced from Vercel Web App
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local') {
        if (changes.chronotask_lists_v1) {
          renderFolderDropdowns();
        }
        if (changes.chronotask_tasks_v1 || changes.chronotask_lists_v1) {
          renderTasks();
        }
        if (changes.chronotask_last_synced || changes.chronotask_user) {
          updateSyncStatus();
        }
      }
    });
  }

  const taskInput = document.getElementById('quickTaskInput');
  if (taskInput) {
    taskInput.addEventListener('keydown', async (e) => {
      if (e.key === 'Enter') {
        const title = e.target.value.trim();
        if (!title) return;
        const folderEl = document.getElementById('quickFolderSelect');
        const folder = folderEl ? folderEl.value : 'default_my_tasks';
        const priorityEl = document.getElementById('quickPrioritySelect');
        const priority = priorityEl ? priorityEl.value : 'medium';
        await addTask(title, folder, priority);
        e.target.value = '';
        renderTasks();
      }
    });
  }

  // Folder creation on quickFolderSelect
  const quickFolderEl = document.getElementById('quickFolderSelect');
  if (quickFolderEl) {
    quickFolderEl.addEventListener('change', async (e) => {
      if (e.target.value === '__NEW_FOLDER__') {
        const createdId = await promptCreateFolder();
        if (createdId) {
          quickFolderEl.value = createdId;
        } else {
          quickFolderEl.value = 'default_my_tasks';
        }
      }
    });
  }

  // Folder creation on editTaskFolder
  const editFolderEl = document.getElementById('editTaskFolder');
  if (editFolderEl) {
    editFolderEl.addEventListener('change', async (e) => {
      if (e.target.value === '__NEW_FOLDER__') {
        const createdId = await promptCreateFolder();
        if (createdId) {
          editFolderEl.value = createdId;
        } else {
          editFolderEl.value = 'default_my_tasks';
        }
      }
    });
  }

  // Folder filter toolbar
  const folderFilterEl = document.getElementById('folderFilterSelect');
  if (folderFilterEl) {
    folderFilterEl.addEventListener('change', (e) => {
      selectedFolderId = e.target.value;
      renderTasks();
    });
  }

  const copyFolderBtn = document.getElementById('copyFolderBtn');
  if (copyFolderBtn) {
    copyFolderBtn.addEventListener('click', copyCurrentFolderTasks);
  }

  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', (e) => {
      document.querySelectorAll('.tab').forEach(t => {
        t.classList.remove('active');
        t.setAttribute('aria-pressed', 'false');
      });
      tab.classList.add('active');
      tab.setAttribute('aria-pressed', 'true');
      currentFilter = tab.dataset.filter || 'today';
      renderTasks();
    });
  });

  // Sort toggle
  const sortToggleBtn = document.getElementById('sortToggleBtn');
  if (sortToggleBtn) {
    sortToggleBtn.addEventListener('click', () => {
      prioritySortHighToLow = !prioritySortHighToLow;
      sortToggleBtn.textContent = prioritySortHighToLow ? '↓ Priority' : '↑ Priority';
      renderTasks();
    });
  }

  const openFullApp = document.getElementById('openFullApp');
  if (openFullApp) {
    openFullApp.addEventListener('click', () => {
      if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.create) {
        chrome.tabs.create({ url: 'https://task-manager-with-google.vercel.app' });
      } else {
        window.open('https://task-manager-with-google.vercel.app', '_blank');
      }
    });
  }

  const footerSync = document.getElementById('openFullAppFooter');
  if (footerSync) {
    footerSync.addEventListener('click', async () => {
      footerSync.textContent = 'Syncing...';
      if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.query) {
        chrome.tabs.query({}, (tabs) => {
          const matchTab = tabs.find(isChronotaskTab);
          if (matchTab && matchTab.id) {
            chrome.tabs.sendMessage(matchTab.id, { type: 'TRIGGER_PAGE_SYNC' }, () => {});
            chrome.tabs.update(matchTab.id, { active: true });
          } else {
            chrome.tabs.create({ url: 'https://task-manager-with-google.vercel.app' });
          }
        });
      } else {
        window.open('https://task-manager-with-google.vercel.app', '_blank');
      }

      setTimeout(async () => {
        await renderFolderDropdowns();
        await renderTasks();
        await updateSyncStatus();
      }, 500);
    });
  }

  const sidePanelBtn = document.getElementById('openSidePanelBtn');
  if (sidePanelBtn) {
    sidePanelBtn.addEventListener('click', async () => {
      if (typeof chrome !== 'undefined' && chrome.sidePanel && chrome.sidePanel.open) {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab && tab.id) {
          chrome.sidePanel.open({ tabId: tab.id });
        }
      }
    });
  }

  // Drawer handlers
  const closeDetailBtn = document.getElementById('closeDetailBtn');
  if (closeDetailBtn) closeDetailBtn.addEventListener('click', closeDetailDrawer);

  const saveDetailBtn = document.getElementById('saveDetailBtn');
  if (saveDetailBtn) saveDetailBtn.addEventListener('click', saveTaskDetail);

  const deleteTaskBtn = document.getElementById('deleteTaskBtn');
  if (deleteTaskBtn) deleteTaskBtn.addEventListener('click', deleteTask);

  document.querySelectorAll('.chip').forEach(chip => {
    chip.addEventListener('click', () => {
      document.querySelectorAll('.chip').forEach(c => c.classList.remove('selected'));
      chip.classList.add('selected');
    });
  });

  // Keyboard: "/" focuses capture, Esc closes the drawer, Cmd/Ctrl+Enter saves.
  document.addEventListener('keydown', (e) => {
    const drawer = document.getElementById('detailDrawer');
    const drawerOpen = drawer && !drawer.classList.contains('hidden');

    if (e.key === 'Escape' && drawerOpen) {
      e.preventDefault();
      closeDetailDrawer();
      return;
    }
    if (drawerOpen && e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      saveTaskDetail();
      return;
    }
    if (e.key === '/' && !e.metaKey && !e.ctrlKey && !e.altKey) {
      const active = document.activeElement;
      const typing = active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA' || active.tagName === 'SELECT' || active.isContentEditable);
      if (!typing) {
        e.preventDefault();
        const input = document.getElementById('quickTaskInput');
        if (input) input.focus();
      }
    }
  });

  window.addEventListener('online', updateSyncStatus);
  window.addEventListener('offline', updateSyncStatus);
});

async function getStoredLists() {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    const result = await chrome.storage.local.get(['chronotask_lists_v1']);
    if (result.chronotask_lists_v1) {
      try {
        const parsed = JSON.parse(result.chronotask_lists_v1);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const map = new Map();
          DEFAULT_FOLDERS.forEach(df => map.set(df.id, df));
          parsed.forEach(p => map.set(p.id, { ...map.get(p.id), ...p }));
          return Array.from(map.values());
        }
      } catch (e) {}
    }
  }
  return DEFAULT_FOLDERS;
}

async function saveStoredLists(lists) {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    await chrome.storage.local.set({ 'chronotask_lists_v1': JSON.stringify(lists) });
  }
}

async function promptCreateFolder() {
  const name = window.prompt('Enter new folder name:');
  if (!name || !name.trim()) return null;
  const safeName = name.trim().slice(0, 100);
  const lists = await getStoredLists();
  const newFolder = {
    id: 'folder_' + Date.now(),
    title: safeName,
    color: '#1e4fd8'
  };
  lists.push(newFolder);
  await saveStoredLists(lists);
  await renderFolderDropdowns();
  return newFolder.id;
}

async function renderFolderDropdowns() {
  const lists = await getStoredLists();

  // 1. Quick folder select
  const quickSelect = document.getElementById('quickFolderSelect');
  if (quickSelect) {
    const currentVal = quickSelect.value || 'default_my_tasks';
    quickSelect.innerHTML = lists.map(l => '<option value="' + escapeHtml(l.id) + '">' + escapeHtml(l.title) + '</option>').join('') +
      '<option value="__NEW_FOLDER__">➕ New Folder...</option>';
    if (lists.some(l => l.id === currentVal)) {
      quickSelect.value = currentVal;
    } else {
      quickSelect.value = lists[0] ? lists[0].id : 'default_my_tasks';
    }
  }

  // 2. Edit folder select in task drawer
  const editSelect = document.getElementById('editTaskFolder');
  if (editSelect) {
    const currentVal = editSelect.value;
    editSelect.innerHTML = lists.map(l => '<option value="' + escapeHtml(l.id) + '">' + escapeHtml(l.title) + '</option>').join('') +
      '<option value="__NEW_FOLDER__">➕ New Folder...</option>';
    if (currentVal && lists.some(l => l.id === currentVal)) {
      editSelect.value = currentVal;
    }
  }

  // 3. Filter folder select in toolbar
  const filterSelect = document.getElementById('folderFilterSelect');
  if (filterSelect) {
    filterSelect.innerHTML = '<option value="all">All folders</option>' +
      lists.map(l => '<option value="' + escapeHtml(l.id) + '">' + escapeHtml(l.title) + '</option>').join('');
    if (selectedFolderId === 'all' || lists.some(l => l.id === selectedFolderId)) {
      filterSelect.value = selectedFolderId;
    } else {
      selectedFolderId = 'all';
      filterSelect.value = 'all';
    }
  }
}

async function getStoredTasks() {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    const result = await chrome.storage.local.get(['chronotask_tasks_v1']);
    const raw = result.chronotask_tasks_v1 ? JSON.parse(result.chronotask_tasks_v1) : [];
    return raw.map(t => ({
      ...t,
      priority: t.priority || 'medium',
      folderId: t.folderId || t.listId || 'default_my_tasks',
    }));
  }
  return [];
}

async function saveStoredTasks(tasks) {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    await chrome.storage.local.set({ 'chronotask_tasks_v1': JSON.stringify(tasks) });
  }
}

async function addTask(title, folderId, priority) {
  const tasks = await getStoredTasks();
  const cleanTitle = (title || '').trim().slice(0, 500);
  if (!cleanTitle) return;
  const cleanFolder = (folderId || 'default_my_tasks').slice(0, 128);
  const cleanPriority = sanitizePriority(priority);
  const newTask = {
    id: 't_' + Date.now(),
    title: cleanTitle,
    listId: cleanFolder,
    folderId: cleanFolder,
    completed: false,
    priority: cleanPriority,
    due: new Date().toISOString().split('T')[0],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    syncStatus: 'local_only'
  };
  tasks.unshift(newTask);
  await saveStoredTasks(tasks);
}

async function toggleTask(id) {
  const tasks = await getStoredTasks();
  const task = tasks.find(t => t.id === id);
  if (task) {
    task.completed = !task.completed;
    task.completedAt = task.completed ? new Date().toISOString() : null;
    task.updatedAt = new Date().toISOString();
    await saveStoredTasks(tasks);
    renderTasks();
  }
}

function openDetailDrawer(task) {
  const drawer = document.getElementById('detailDrawer');
  if (!drawer) return;
  editingTaskId = task.id;

  const titleEl = document.getElementById('editTaskTitle');
  if (titleEl) titleEl.value = task.title || '';

  const folderEl = document.getElementById('editTaskFolder');
  if (folderEl) folderEl.value = task.folderId || task.listId || 'default_my_tasks';

  const dueEl = document.getElementById('editTaskDue');
  if (dueEl) dueEl.value = task.due || '';

  const notesEl = document.getElementById('editTaskNotes');
  if (notesEl) notesEl.value = task.notes || '';

  document.querySelectorAll('.chip').forEach(c => {
    c.classList.toggle('selected', c.dataset.p === (task.priority || 'medium'));
  });

  drawer.classList.remove('hidden');
  const focusTarget = document.getElementById('editTaskTitle');
  if (focusTarget) focusTarget.focus();
}

function closeDetailDrawer() {
  const drawer = document.getElementById('detailDrawer');
  if (drawer) drawer.classList.add('hidden');
  editingTaskId = null;
  const quick = document.getElementById('quickTaskInput');
  if (quick) quick.focus();
}

async function saveTaskDetail() {
  if (!editingTaskId) return;
  const tasks = await getStoredTasks();
  const task = tasks.find(t => t.id === editingTaskId);
  if (task) {
    const titleEl = document.getElementById('editTaskTitle');
    const title = titleEl ? titleEl.value.trim().slice(0, 500) : '';
    if (!title) return;

    const selectedChip = document.querySelector('.chip.selected');
    const rawPriority = selectedChip && selectedChip.dataset.p ? selectedChip.dataset.p : 'medium';
    const priority = sanitizePriority(rawPriority);

    const folderEl = document.getElementById('editTaskFolder');
    if (folderEl) {
      task.folderId = (folderEl.value || 'default_my_tasks').slice(0, 128);
      task.listId = task.folderId;
    }

    const dueEl = document.getElementById('editTaskDue');
    const rawDue = dueEl && dueEl.value ? dueEl.value : '';
    task.due = /^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(rawDue) ? rawDue : undefined;

    const notesEl = document.getElementById('editTaskNotes');
    task.notes = notesEl && notesEl.value.trim() ? notesEl.value.trim().slice(0, 2000) : undefined;

    task.title = title;
    task.priority = priority;
    task.updatedAt = new Date().toISOString();

    await saveStoredTasks(tasks);
    closeDetailDrawer();
    renderTasks();
  }
}

async function deleteTask() {
  if (!editingTaskId) return;
  let tasks = await getStoredTasks();
  tasks = tasks.filter(t => t.id !== editingTaskId);
  await saveStoredTasks(tasks);
  closeDetailDrawer();
  renderTasks();
}

async function copyText(text, feedbackButton) {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
    } else {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
    }
    if (feedbackButton) {
      const original = feedbackButton.textContent;
      feedbackButton.textContent = 'Copied!';
      setTimeout(() => { feedbackButton.textContent = original; }, 1400);
    }
  } catch (e) {
    console.warn('Copy failed:', e);
  }
}

function formatTaskForCopy(task, listMap) {
  const folder = listMap.get(task.folderId || task.listId || 'default_my_tasks');
  const details = [
    task.completed ? 'Completed' : 'Open',
    (task.priority || 'medium') + ' priority',
    task.due ? 'Due ' + task.due + (task.dueTime ? ' at ' + task.dueTime : '') : '',
    folder ? 'Folder: ' + folder.title : ''
  ].filter(Boolean);
  return [task.title || 'Untitled task', details.join(' · '), task.notes || ''].filter(Boolean).join('\n');
}

async function copyTaskById(taskId, button) {
  const [tasks, lists] = await Promise.all([getStoredTasks(), getStoredLists()]);
  const task = tasks.find(t => t.id === taskId);
  if (!task) return;
  const listMap = new Map();
  lists.forEach(list => listMap.set(list.id, list));
  await copyText(formatTaskForCopy(task, listMap), button);
}

async function copyCurrentFolderTasks() {
  const [tasks, lists] = await Promise.all([getStoredTasks(), getStoredLists()]);
  const listMap = new Map();
  lists.forEach(list => listMap.set(list.id, list));
  const selectedTasks = selectedFolderId === 'all'
    ? tasks
    : tasks.filter(task => (task.folderId || task.listId || 'default_my_tasks') === selectedFolderId);
  const folderTitle = selectedFolderId === 'all'
    ? 'All Tasks'
    : (listMap.get(selectedFolderId) || {}).title || 'Folder Tasks';
  const text = [
    folderTitle + ' — ' + selectedTasks.length + ' task' + (selectedTasks.length === 1 ? '' : 's'),
    '',
    ...selectedTasks.map((task, index) => (index + 1) + '. ' + formatTaskForCopy(task, listMap))
  ].join('\n\n');
  await copyText(text, document.getElementById('copyFolderBtn'));
}

async function renderTasks() {
  const container = document.getElementById('taskList');
  if (!container) return;

  const [tasks, lists] = await Promise.all([getStoredTasks(), getStoredLists()]);
  const listMap = new Map();
  lists.forEach(l => listMap.set(l.id, l));

  const today = new Date().toISOString().split('T')[0];

  let filtered = tasks;
  if (currentFilter === 'today') {
    filtered = tasks.filter(t => t.due === today || (!t.completed && (!t.due || t.due <= today)));
  } else if (currentFilter === 'upcoming') {
    filtered = tasks.filter(t => t.due && t.due > today && !t.completed);
  }

  // Filter by selected folder if not 'all'
  if (selectedFolderId !== 'all') {
    filtered = filtered.filter(t => (t.folderId || t.listId || 'default_my_tasks') === selectedFolderId);
  }

  // Priority Sorting (High to Low)
  filtered.sort((a, b) => {
    const wa = PRIORITY_WEIGHT[a.priority] || 2;
    const wb = PRIORITY_WEIGHT[b.priority] || 2;
    if (prioritySortHighToLow) {
      if (wb !== wa) return wb - wa;
    } else {
      if (wa !== wb) return wa - wb;
    }
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  if (filtered.length === 0) {
    container.innerHTML = '<div class="empty-state">No tasks in this view. Press Enter above to add one.</div>';
    return;
  }

  container.innerHTML = filtered.map(t => {
    const fId = t.folderId || t.listId || 'default_my_tasks';
    const folder = listMap.get(fId);
    const folderTitle = folder ? folder.title : 'General';
    let folderStyle = '';
    let extraCls = '';
    if (fId === 'default_urgent') extraCls = 'folder-urgent';
    else if (fId === 'default_work') extraCls = 'folder-work';
    else if (folder && isValidHexColor(folder.color)) {
      folderStyle = 'border-color: ' + folder.color + '40; color: ' + folder.color + ';';
    }

    const safeTaskId = escapeHtml(t.id || '');
    const safeTitle = escapeHtml(t.title || '');
    const safeLabel = escapeHtml(t.title || 'Untitled task');
    const folderBadge = selectedFolderId === 'all'
      ? '<span class="folder-badge ' + extraCls + '" style="' + folderStyle + '">' + escapeHtml(folderTitle) + '</span> '
      : '';
    const isCompleted = Boolean(t.completed);
    const pTag = sanitizePriority(t.priority);
    const dueLabel = t.due ? (t.due === today ? 'Today' : escapeHtml(t.due)) : '';
    const dueSpan = dueLabel ? '<span>· ' + dueLabel + '</span>' : '';
    const noteSpan = t.notes ? '<span>· Note</span>' : '';

    return '<div class="task-item ' + (isCompleted ? 'completed' : '') + '" data-id="' + safeTaskId + '">' +
      '<label class="task-check"><input type="checkbox" class="task-checkbox" ' + (isCompleted ? 'checked' : '') + ' aria-label="Complete ' + safeLabel + '"></label>' +
      '<div class="task-content">' +
        '<div class="task-title">' +
          folderBadge +
          safeTitle +
        '</div>' +
        '<div class="task-meta">' +
          '<span class="priority-tag priority-' + pTag + '">' + pTag + '</span>' +
          dueSpan +
          noteSpan +
        '</div>' +
      '</div>' +
      '<button type="button" class="task-copy" data-id="' + safeTaskId + '" title="Copy task" aria-label="Copy task">⧉</button>' +
    '</div>';
  }).join('');

  container.querySelectorAll('.task-check').forEach(label => {
    label.addEventListener('click', (e) => e.stopPropagation());
  });

  container.querySelectorAll('.task-checkbox').forEach(cb => {
    cb.addEventListener('click', (e) => {
      e.stopPropagation();
      const parent = e.target.closest('.task-item');
      if (parent && parent.dataset.id) {
        toggleTask(parent.dataset.id);
      }
    });
  });

  container.querySelectorAll('.task-copy').forEach(button => {
    button.addEventListener('click', (e) => {
      e.stopPropagation();
      copyTaskById(button.dataset.id, button);
    });
  });

  // Click on task opens detail edit drawer
  container.querySelectorAll('.task-item').forEach(item => {
    item.addEventListener('click', (e) => {
      if (e.target.classList.contains('task-checkbox') || e.target.classList.contains('task-copy')) return;
      const taskId = item.dataset.id;
      const targetTask = tasks.find(t => t.id === taskId);
      if (targetTask) {
        openDetailDrawer(targetTask);
      }
    });
  });
}

function isValidHexColor(color) {
  return typeof color === 'string' && /^#[0-9a-fA-F]{6}$/.test(color);
}

function sanitizePriority(priority) {
  const allowed = ['urgent', 'high', 'medium', 'low'];
  return allowed.indexOf(priority) >= 0 ? priority : 'medium';
}

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

async function updateSyncStatus() {
  const statusEl = document.getElementById('syncStatus');
  const labelEl = document.getElementById('syncLabel');
  const footerSync = document.getElementById('openFullAppFooter');

  function setState(state, text, title) {
    if (statusEl) {
      statusEl.classList.remove('is-online', 'is-offline', 'is-local');
      statusEl.classList.add('is-' + state);
      if (title) statusEl.title = title;
    }
    if (labelEl) labelEl.textContent = text;
  }

  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    setState('offline', 'Offline', 'This browser has no network connection');
    if (footerSync) footerSync.textContent = 'Sync Google Tasks ↗';
    return;
  }

  try {
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
      setState('local', 'Local only', 'Extension storage is unavailable');
      if (footerSync) footerSync.textContent = 'Sync Google Tasks ↗';
      return;
    }
    const data = await chrome.storage.local.get(['chronotask_last_synced', 'chronotask_user']);
    let user = null;
    try { user = data.chronotask_user ? JSON.parse(data.chronotask_user) : null; } catch (e) {}

    if (!data.chronotask_last_synced) {
      setState('local', 'Local only', 'Not connected to the web app yet. Use Sync Google Tasks.');
      if (footerSync) footerSync.textContent = 'Sync Google Tasks ↗';
      return;
    }

    const when = new Date(data.chronotask_last_synced);
    const minutes = Math.max(0, Math.floor((Date.now() - when.getTime()) / 60000));
    const relative = minutes < 1 ? 'just now' : minutes < 60 ? minutes + 'm ago' : Math.floor(minutes / 60) + 'h ago';
    const timeStr = when.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const stale = minutes > 60 * 24;
    const who = user && user.email ? 'Connected: ' + user.email + ' · ' : '';
    setState(
      stale ? 'offline' : 'online',
      stale ? 'Stale' : 'Synced ' + relative,
      who + 'Last sync ' + timeStr
    );
    if (footerSync) {
      footerSync.textContent = '✓ Synced ' + timeStr + ' ↗';
      footerSync.title = who + 'Synced with the web app at ' + timeStr;
    }
  } catch (e) {
    setState('local', 'Local only', 'Sync status unavailable');
    if (footerSync) footerSync.textContent = 'Sync Google Tasks ↗';
  }
}
